var w = 800,h = 1200;
var bounds=15000;
var player, player2, keyboard, gameover, base, base2, button, buttonLeft, buttonRight, buttonUp, buttonDown;
var score = 0;
var scoreText;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');
var titlepage;
var startButton;
var aboutButton;
var winnerpage;
var restartbutton;
var gamepage;
var teamBScore =0;
var scoreTextB;
var defpage;
var menuText;
var aboutText;
var aboutpage;
var menuButton;
var instructionButton;
var instructionpage;


game.state.add("bootGame",bootGame);
game.state.add("preloadGame",preloadGame);
game.state.add("menuGame",menuGame);
game.state.add("playGame",playGame);
game.state.add("winGame",winGame);
game.state.add("loseGame",loseGame);

game.state.start("bootGame");