bootGame = {
	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
    	
		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forceLascape = true;
    	game.scale.pageAlignHorizontally = true;
   		game.scale.pageAlignVertically = true;
    	game.world.setBounds(0,0,800,1200);

    	
    	game.state.start("preloadGame");
    	
    	
	},
		update: function () {
   		game.scale.pageAlignVertically = true;
    	game.scale.pageAlignHorizontally = true;
    	game.scale.setShowAll();
    	game.scale.refresh();
	}

}
preloadGame = {
	preload:function(){
		game.load.image("background","img/main2.png");
    	game.load.image("base","img/base.png");
    	game.load.image("base2","img/base.png");
    	game.load.image("title","img/title.png");
    	game.load.image("winner","img/winner.png");
    	game.load.image('restart','img/restart.png',338,0);
    	game.load.image('gameover','img/gameover.png');
        game.load.image('instruction','img/instruction.png');
        game.load.image('about2','img/about2.png');
    	game.load.image('defeat','img/def.png');
        game.load.audio('kansyon','audio/background.mp3');
        game.load.audio('panalo','audio/victory.mp3');
        game.load.audio('base','audio/base.mp3');
    
    

   		game.load.spritesheet("start","img/startbut.png",250,0);
        game.load.spritesheet("intruc","img/instrucbut.png",134,0);
   		game.load.spritesheet("about","img/about.png",250,0);
   		game.load.spritesheet("menu","img/menu.png",234,0);
        game.load.spritesheet("menu2","img/menu2.png",200,0);
    	game.load.spritesheet('character','img/character.png',63,150);
    	game.load.spritesheet('player2','img/player 2.png',63,150);
    	game.load.spritesheet('player3','img/player3.png',63,150);
    	game.load.spritesheet('pauseButton','img/pause.png',34,0);
        game.load.spritesheet('back','img/back.png',34,0);
    	game.load.spritesheet('leftButton','img/leftbut.png',79,0);
    	game.load.spritesheet('rightButton','img/rightbut.png',79,0);
    	game.load.spritesheet('upButton','img/upbut.png',79,0);
    	game.load.spritesheet('downButton','img/downbut.png',79,0);

	},
	create:function(){
		game.state.start("menuGame");
	}
}
menuGame = {
	create:function(){
		titlepage = game.add.sprite(0,0, "title");
		startButton = game.add.button(300,800,'start', this.actionOnClick, this);
		aboutButton = game.add.button(300,950,'about',this.aboutOnClick, this);
        instructionButton = game.add.button(600,1050,'intruc',this.instructionOnClick, this);
		menu = game.add.sprite(100,650,"menu");
        

		menu.scale.x = 1.5;
		menu.scale.y = 1.5;

	},
	actionOnClick: function(){
        titlepage.visible =! startButton.visible;
        startButton.destroy();
        game.state.start("playGame");

    },
    aboutOnClick: function(){
            aboutpage=game.add.image(0,0,"about2");
            restartButton=game.add.button(100,100,"menu2",restartB,this);
            function restartB() {
            aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

            //window.location.href=window.location.href;
            game.state.start("menuGame");
            }
        },
    instructionOnClick: function(){
            instructionpage=game.add.image(0,0,"instruction");
            restartButton=game.add.button(100,100,"menu2",restartB,this);
            function restartB() {
            instructionpage.visible =! restartButton.visible;
            restartButton.destroy();

            //window.location.href=window.location.href;
            game.state.start("menuGame");
            }
        },

   

}
playGame = {
	create:function(){
		game.add.sprite(0,0,'background');
		player = game.add.sprite(200,900,'character');
   		player2 = game.add.sprite(500,100,'player2');
    	player3 = game.add.sprite(550,250,'player3');

    	player.animations.add('walk-right',[8,9,10,11],7,true);
    	player.animations.add('walk-left',[7,6,5,4],7,true);
    	player.animations.add('walk-up',[12,13,14,15],7,true);
    	player.animations.add('walk-down',[0,1,2,3],7,true);

    	player2.animations.add('walk-right',[8,9,10,11],7,true);
    	player2.animations.add('walk-left',[7,6,5,4],7,true);
    	player2.animations.add('walk-up',[12,13,14,15],7,true);
    	player2.animations.add('walk-down',[0,1,2,3],7,true);

    	player3.animations.add('walk-right',[8,9,10,11],7,true);
    	player3.animations.add('walk-left',[7,6,5,4],7,true);
    	player3.animations.add('walk-up',[12,13,14,15],7,true);
    	player3.animations.add('walk-down',[0,1,2,3],7,true);

    	buttonLeft = game.add.button(600,1050,"leftButton",this.walkLeft);
    	buttonRight = game.add.button(700,1050,"rightButton",this.walkRight);
    	buttonUp = game.add.button(100,1000,"upButton",this.walkUp);
    	buttonDown = game.add.button(100,1100,"downButton",this.walkDown);

        kansyon =game.add.audio("kansyon",1,true);
        kansyon.Loop =true;
        kansyon.play();


        panalo =game.add.audio("panalo",1,true);
        base =game.add.audio("base",1,true);

            restartButton=game.add.button(100,50,"back",restartB,this);
            function restartB() {   
            restartButton.destroy();
            
            window.location.href=window.location.href;
            }

    	base = game.add.sprite(350,100,"base");
    	game.physics.arcade.enable(base);

    	base.body.immovable = true;

    	base2 = game.add.sprite(350,1000,"base2");
    	game.physics.arcade.enable(base2);

    	base2.body.immovable = true;

    	game.physics.arcade.enable(player);
    	player.body.collideWorldBounds = true;
    	//player.body.gravity.y = 1000;

    	game.physics.arcade.enable(player2);
    	player2.body.collideWorldBounds = true;
    
    	game.physics.arcade.enable(player3);
    	player3.body.collideWorldBounds = true;
    	player3.body.velocity.x=-200;
    	player3.animations.play('walk-down');
    	player3.body.bounce.x=1;

    	this.pauseButton = this.game.add.sprite(700,50, 'pauseButton');
    	this.pauseButton.inputEnabled = true;
    	this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
    	this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this); 

    	scoreText = game.add.text(100, 100, 'TeamAScore: 0', {fontSize: '64px Arial', fill: '#FFFFFF'});
    	scoreTextB = game.add.text(500, 100, 'TeamBScore: 0', {fontSize: '64px Arial', fill: '#FFFFFF'});
},
	update:function(){
		game.scale.pageAlignVertically = true;
    	game.scale.pageAlignHorizontally = true;
    	game.scale.setShowAll();
    	game.scale.refresh();

    	game.physics.arcade.overlap(player2,base2,this.touchBaseB);
    	game.physics.arcade.collide(player,base2);
    	game.physics.arcade.overlap(player,base,this.touchBaseA);
    	game.physics.arcade.collide(player,base);
    	game.physics.arcade.collide(player2,base2);
    	game.physics.arcade.collide(player2,base);
    	game.physics.arcade.collide(player,player2,this.touchPlayer);
    	game.physics.arcade.collide(player,player2);
    	game.physics.arcade.collide(player,player3,this.touchPlayerB);
    	game.physics.arcade.collide(player,player3);
    	game.physics.arcade.collide(player2,player3);
    
    

},
walkLeft: function() {
        buttonLeft.frame = 1;
        player.animations.play('walk-left');
        player.body.velocity.x = -500;
        player2.animations.play('walk-right');
        player2.body.velocity.x = 100;
        
    
    setTimeout(function(){
        buttonLeft.frame = 0;
        player.body.velocity.x = 0;
        player2.body.velocity.x = 300;
        //player.animations.stop();
    },100)
},
        walkRight: function(){
        buttonRight.frame = 1;
        player.animations.play('walk-right');
        player.body.velocity.x = 500;
        player2.animations.play('walk-left');
        player2.body.velocity.x = -100;
        
        setTimeout(function(){
        buttonRight.frame = 0;
        player.body.velocity.x = 0;
        player2.body.velocity.x =-300;
        },100)
},
        walkUp: function() {
        buttonUp.frame = 1;
        player.body.velocity.y = -500;
        player.animations.play('walk-up');
        player2.animations.play('walk-down');
        player2.body.velocity.y = 100;
        

        setTimeout(function(){
        buttonUp.frame = 0;
        player.body.velocity.y = 0;
        //player.animations.stop();
        },100)
},
        walkDown: function() {
        buttonDown.frame = 1;
        player.body.velocity.y = 500;
        player.animations.play('walk-down');
        player2.animations.play('walk-up');
        player2.body.velocity.y = -100;

        setTimeout(function(){
        buttonDown.frame = 0;
        player.body.velocity.y = 0;
        //player.animations.stop();
        },100)
},
        touchBaseA: function (player,base) {
        score +=1;
        scoreText.text = 'TeamAScore: ' + score;
        base.play();

        if(score>=5) {
           winnerpage=game.add.image(0,0,"winner");
           kansyon.stop();
           panalo.play();

           game._paused = true
        
            restartButton=game.add.button(250,800,"restart",restartB,this);
            function restartB() {
            winnerpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }
    }
},
        touchBaseB: function (player2,base2) {
        teamBScore +=1;
        scoreTextB.text = 'TeamBScore:  ' + teamBScore;
        base.play();

        if(teamBScore>=5) {
           defeatpage=game.add.image(0,0,"defeat");
           kansyon.stop();

           game._paused = true
        
            restartButton=game.add.button(250,800,"restart",restartB,this);
            function restartB() {
            defeatpage.visible =! restartButton.visible;
            restartButton.destroy();

            window.location.href=window.location.href;
            }
    }
},
        touchPlayer:function(player,player2){
        player.kill();
        game._paused = true

        kansyon.stop();
    
        gamepage=game.add.image(0,0,"gameover");

        restartButton=game.add.button(250,800,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

},
        touchPlayerB:function(player,player3){
        player.kill();
        game._paused = true
        
        kansyon.stop();

        gamepage=game.add.image(0,0,"gameover");

        restartButton=game.add.button(250,800,"restart",restartB,this);
        function restartB() {
        gamepage.visible =! restartButton.visible;
        restartButton.destroy();

        window.location.href=window.location.href;
            }

        //game.input.onTap.addOnce(restart,this);
},
 restart: function() {
        window.location.href=window.location.href;
        stateText.visible = false;
},
loopAudio:function(time){
    setInterval(function(){
        kansyon.play();
    },time)
},
	}


winGame = {
	
}
loseGame = {
	
}

